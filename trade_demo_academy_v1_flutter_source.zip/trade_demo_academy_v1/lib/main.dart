import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TradeDemoAcademyApp());
}

class TradeDemoAcademyApp extends StatelessWidget {
  const TradeDemoAcademyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'آکادمی ترید دمو',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: null,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00D09C),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF07111F),
        useMaterial3: true,
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: TradingHome(),
      ),
    );
  }
}

class MarketAsset {
  final String symbol;
  final String title;
  final String subtitle;
  final String badge;
  final double fallbackPrice;

  const MarketAsset({
    required this.symbol,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.fallbackPrice,
  });
}

const List<MarketAsset> marketAssets = [
  MarketAsset(
    symbol: 'BTCUSDT',
    title: 'Bitcoin',
    subtitle: 'BTC / USDT',
    badge: 'BTC',
    fallbackPrice: 65000,
  ),
  MarketAsset(
    symbol: 'ETHUSDT',
    title: 'Ethereum',
    subtitle: 'ETH / USDT',
    badge: 'ETH',
    fallbackPrice: 3500,
  ),
  MarketAsset(
    symbol: 'BNBUSDT',
    title: 'BNB',
    subtitle: 'BNB / USDT',
    badge: 'BNB',
    fallbackPrice: 600,
  ),
  MarketAsset(
    symbol: 'SOLUSDT',
    title: 'Solana',
    subtitle: 'SOL / USDT',
    badge: 'SOL',
    fallbackPrice: 140,
  ),
  MarketAsset(
    symbol: 'XRPUSDT',
    title: 'XRP',
    subtitle: 'XRP / USDT',
    badge: 'XRP',
    fallbackPrice: 0.62,
  ),
  MarketAsset(
    symbol: 'DOGEUSDT',
    title: 'Dogecoin',
    subtitle: 'DOGE / USDT',
    badge: 'DOGE',
    fallbackPrice: 0.14,
  ),
];

class PaperTrade {
  final String id;
  final String symbol;
  final String title;
  final String side;
  final double amount;
  final double entryPrice;
  final int openedAt;

  const PaperTrade({
    required this.id,
    required this.symbol,
    required this.title,
    required this.side,
    required this.amount,
    required this.entryPrice,
    required this.openedAt,
  });

  double pnl(double currentPrice) {
    if (entryPrice <= 0) return 0;
    final change = (currentPrice - entryPrice) / entryPrice;
    return side == 'BUY' ? amount * change : amount * -change;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'symbol': symbol,
        'title': title,
        'side': side,
        'amount': amount,
        'entryPrice': entryPrice,
        'openedAt': openedAt,
      };

  factory PaperTrade.fromJson(Map<String, dynamic> json) => PaperTrade(
        id: json['id']?.toString() ?? '',
        symbol: json['symbol']?.toString() ?? '',
        title: json['title']?.toString() ?? '',
        side: json['side']?.toString() ?? 'BUY',
        amount: _asDouble(json['amount']),
        entryPrice: _asDouble(json['entryPrice']),
        openedAt: (json['openedAt'] as num?)?.toInt() ?? 0,
      );
}

class ClosedTrade {
  final PaperTrade trade;
  final double exitPrice;
  final double profit;
  final int closedAt;

  const ClosedTrade({
    required this.trade,
    required this.exitPrice,
    required this.profit,
    required this.closedAt,
  });

  Map<String, dynamic> toJson() => {
        'trade': trade.toJson(),
        'exitPrice': exitPrice,
        'profit': profit,
        'closedAt': closedAt,
      };

  factory ClosedTrade.fromJson(Map<String, dynamic> json) => ClosedTrade(
        trade: PaperTrade.fromJson(
          Map<String, dynamic>.from(json['trade'] as Map? ?? {}),
        ),
        exitPrice: _asDouble(json['exitPrice']),
        profit: _asDouble(json['profit']),
        closedAt: (json['closedAt'] as num?)?.toInt() ?? 0,
      );
}

class MarketService {
  static Future<Map<String, double>> fetchPrices() async {
    final Map<String, double> result = {};
    for (final asset in marketAssets) {
      final uri = Uri.https('api.binance.com', '/api/v3/ticker/price', {
        'symbol': asset.symbol,
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body) as Map<String, dynamic>;
        final price = double.tryParse(decoded['price']?.toString() ?? '');
        if (price != null && price > 0) {
          result[asset.symbol] = price;
        }
      }
    }
    return result;
  }
}

class TradingHome extends StatefulWidget {
  const TradingHome({super.key});

  @override
  State<TradingHome> createState() => _TradingHomeState();
}

class _TradingHomeState extends State<TradingHome> {
  bool _loading = true;
  bool _initialized = false;
  bool _updatingPrices = false;
  String _userName = '';
  double _balance = 1000;
  int _tab = 0;
  Timer? _timer;

  final Map<String, double> _prices = {
    for (final asset in marketAssets) asset.symbol: asset.fallbackPrice,
  };
  final Map<String, List<double>> _history = {
    for (final asset in marketAssets) asset.symbol: <double>[asset.fallbackPrice],
  };

  List<PaperTrade> _openTrades = [];
  List<ClosedTrade> _closedTrades = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final openRaw = prefs.getString('openTrades') ?? '[]';
    final closedRaw = prefs.getString('closedTrades') ?? '[]';

    setState(() {
      _initialized = prefs.getBool('initialized') ?? false;
      _userName = prefs.getString('userName') ?? '';
      _balance = prefs.getDouble('balance') ?? 1000;
      _openTrades = _decodeOpenTrades(openRaw);
      _closedTrades = _decodeClosedTrades(closedRaw);
      _loading = false;
    });

    if (_initialized) {
      unawaited(_refreshPrices());
      _timer = Timer.periodic(const Duration(seconds: 6), (_) => _refreshPrices());
    }
  }

  Future<void> _saveCore() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('initialized', _initialized);
    await prefs.setString('userName', _userName);
    await prefs.setDouble('balance', _balance);
    await prefs.setString(
      'openTrades',
      jsonEncode(_openTrades.map((trade) => trade.toJson()).toList()),
    );
    await prefs.setString(
      'closedTrades',
      jsonEncode(_closedTrades.map((trade) => trade.toJson()).toList()),
    );
  }

  Future<void> _startWithName(String name) async {
    final clean = name.trim();
    if (clean.length < 2) {
      _toast('اسم حداقل باید ۲ کاراکتر باشد.');
      return;
    }
    setState(() {
      _userName = clean;
      _initialized = true;
      _balance = 1000;
      _openTrades = [];
      _closedTrades = [];
    });
    await _saveCore();
    await _refreshPrices();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 6), (_) => _refreshPrices());
  }

  Future<void> _refreshPrices() async {
    if (_updatingPrices) return;
    setState(() => _updatingPrices = true);
    try {
      final fresh = await MarketService.fetchPrices();
      if (!mounted) return;
      setState(() {
        for (final entry in fresh.entries) {
          _prices[entry.key] = entry.value;
          final list = _history.putIfAbsent(entry.key, () => <double>[]);
          list.add(entry.value);
          if (list.length > 36) list.removeAt(0);
        }
      });
    } catch (_) {
      if (mounted) _toast('قیمت زنده دریافت نشد؛ آخرین قیمت ذخیره‌شده نمایش داده می‌شود.');
    } finally {
      if (mounted) setState(() => _updatingPrices = false);
    }
  }

  double get _openPnl {
    double total = 0;
    for (final trade in _openTrades) {
      total += trade.pnl(_prices[trade.symbol] ?? trade.entryPrice);
    }
    return total;
  }

  double get _equity => _balance + _openTrades.fold<double>(0, (sum, t) => sum + t.amount) + _openPnl;

  Future<void> _openTrade(MarketAsset asset, String side, double amount) async {
    final price = _prices[asset.symbol] ?? asset.fallbackPrice;
    if (amount <= 0) {
      _toast('مبلغ معامله معتبر نیست.');
      return;
    }
    if (amount > _balance) {
      _toast('موجودی آزاد کافی نیست.');
      return;
    }
    final trade = PaperTrade(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      symbol: asset.symbol,
      title: asset.title,
      side: side,
      amount: amount,
      entryPrice: price,
      openedAt: DateTime.now().millisecondsSinceEpoch,
    );
    setState(() {
      _balance -= amount;
      _openTrades.insert(0, trade);
    });
    await _saveCore();
    _toast('معامله دمو باز شد.');
  }

  Future<void> _closeTrade(PaperTrade trade) async {
    final current = _prices[trade.symbol] ?? trade.entryPrice;
    final profit = trade.pnl(current);
    final settlement = math.max(0, trade.amount + profit);
    setState(() {
      _openTrades.removeWhere((item) => item.id == trade.id);
      _closedTrades.insert(
        0,
        ClosedTrade(
          trade: trade,
          exitPrice: current,
          profit: profit,
          closedAt: DateTime.now().millisecondsSinceEpoch,
        ),
      );
      _balance += settlement;
    });
    await _saveCore();
    _toast(profit >= 0 ? 'معامله با سود بسته شد.' : 'معامله با ضرر بسته شد.');
  }

  Future<void> _resetAccount() async {
    setState(() {
      _balance = 1000;
      _openTrades = [];
      _closedTrades = [];
    });
    await _saveCore();
    _toast('حساب دمو دوباره با ۱۰۰۰ دلار شروع شد.');
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, textDirection: TextDirection.rtl),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (!_initialized) {
      return OnboardingScreen(onStart: _startWithName);
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFF0B1B31), Color(0xFF06101D), Color(0xFF07111F)],
          ),
        ),
        child: SafeArea(
          child: IndexedStack(
            index: _tab,
            children: [
              _DashboardPage(
                userName: _userName,
                balance: _balance,
                equity: _equity,
                openPnl: _openPnl,
                openTrades: _openTrades,
                closedTrades: _closedTrades,
                updatingPrices: _updatingPrices,
                onRefresh: _refreshPrices,
                onReset: _resetAccount,
              ),
              _MarketsPage(
                prices: _prices,
                history: _history,
                updatingPrices: _updatingPrices,
                onRefresh: _refreshPrices,
                onOpenTrade: _showTradeSheet,
              ),
              _TradesPage(
                openTrades: _openTrades,
                closedTrades: _closedTrades,
                prices: _prices,
                onClose: _closeTrade,
              ),
              const _LearnPage(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        backgroundColor: const Color(0xFF081321),
        indicatorColor: const Color(0xFF00D09C).withOpacity(0.16),
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.candlestick_chart_rounded), label: 'بازار'),
          NavigationDestination(icon: Icon(Icons.receipt_long_rounded), label: 'معاملات'),
          NavigationDestination(icon: Icon(Icons.school_rounded), label: 'آموزش'),
        ],
      ),
    );
  }

  void _showTradeSheet(MarketAsset asset) {
    final controller = TextEditingController(text: '100');
    String side = 'BUY';
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0C1A2D),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: StatefulBuilder(
            builder: (context, setModalState) {
              final price = _prices[asset.symbol] ?? asset.fallbackPrice;
              return Padding(
                padding: EdgeInsets.only(
                  left: 18,
                  right: 18,
                  top: 18,
                  bottom: MediaQuery.of(context).viewInsets.bottom + 18,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        _CoinBadge(text: asset.badge),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(asset.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                              Text('قیمت فعلی: ${formatMoney(price)}', style: mutedStyle()),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: _ChoiceButton(
                            label: 'Buy / خرید',
                            active: side == 'BUY',
                            positive: true,
                            onTap: () => setModalState(() => side = 'BUY'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _ChoiceButton(
                            label: 'Sell / فروش',
                            active: side == 'SELL',
                            positive: false,
                            onTap: () => setModalState(() => side = 'SELL'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: controller,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: 'مبلغ ورود به معامله دمو',
                        suffixText: '\$',
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.06),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text('موجودی آزاد: ${formatMoney(_balance)}', style: mutedStyle()),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('باز کردن معامله دمو'),
                      onPressed: () {
                        final amount = double.tryParse(controller.text.trim().replaceAll(',', '.')) ?? 0;
                        Navigator.pop(context);
                        _openTrade(asset, side, amount);
                      },
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'این معامله واقعی نیست و فقط برای تمرین آموزشی داخل گوشی ذخیره می‌شود.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF8CA0BA), fontSize: 12),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  final Future<void> Function(String name) onStart;
  const OnboardingScreen({super.key, required this.onStart});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final TextEditingController _nameController = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(22),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF102A43), Color(0xFF07111F)],
          ),
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Container(
                padding: const EdgeInsets.all(22),
                decoration: premiumBox(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      width: 82,
                      height: 82,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(colors: [Color(0xFF00D09C), Color(0xFF2DE2E6)]),
                        boxShadow: [BoxShadow(color: const Color(0xFF00D09C).withOpacity(0.25), blurRadius: 30)],
                      ),
                      child: const Icon(Icons.trending_up_rounded, color: Colors.black, size: 42),
                    ),
                    const SizedBox(height: 22),
                    const Text(
                      'آکادمی ترید دمو',
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'با ۱۰۰۰ دلار سرمایه دمو تمرین کن، قیمت واقعی کریپتو را ببین و بدون پول واقعی معامله آموزشی انجام بده.',
                      style: mutedStyle(height: 1.8),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: _nameController,
                      textInputAction: TextInputAction.done,
                      decoration: InputDecoration(
                        labelText: 'اسم شما',
                        hintText: 'مثلاً نوید',
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.06),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                      ),
                      onSubmitted: (_) => _submit(),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _busy ? null : _submit,
                      icon: _busy
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.account_balance_wallet_rounded),
                      label: const Text('شروع با ۱۰۰۰ دلار دمو'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'تمام اطلاعات فقط روی گوشی ذخیره می‌شود. ثبت‌نام واقعی، سرور و بک‌اند وجود ندارد.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF8CA0BA), fontSize: 12),
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    await widget.onStart(_nameController.text);
    if (mounted) setState(() => _busy = false);
  }
}

class _DashboardPage extends StatelessWidget {
  final String userName;
  final double balance;
  final double equity;
  final double openPnl;
  final List<PaperTrade> openTrades;
  final List<ClosedTrade> closedTrades;
  final bool updatingPrices;
  final VoidCallback onRefresh;
  final VoidCallback onReset;

  const _DashboardPage({
    required this.userName,
    required this.balance,
    required this.equity,
    required this.openPnl,
    required this.openTrades,
    required this.closedTrades,
    required this.updatingPrices,
    required this.onRefresh,
    required this.onReset,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('سلام $userName', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                  Text('تمرین ترید با سرمایه دمو', style: mutedStyle()),
                ],
              ),
            ),
            IconButton.filledTonal(
              onPressed: updatingPrices ? null : onRefresh,
              icon: updatingPrices
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [Color(0xFF00D09C), Color(0xFF17BEBB)]),
            boxShadow: [BoxShadow(color: const Color(0xFF00D09C).withOpacity(0.24), blurRadius: 35, offset: const Offset(0, 18))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ارزش حساب دمو', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(formatMoney(equity), style: const TextStyle(color: Colors.black, fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Text('موجودی آزاد: ${formatMoney(balance)}', style: const TextStyle(color: Colors.black87)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _StatBox(title: 'سود/ضرر باز', value: signedMoney(openPnl), positive: openPnl >= 0)),
            const SizedBox(width: 12),
            Expanded(child: _StatBox(title: 'معامله باز', value: openTrades.length.toString(), positive: true)),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: _StatBox(title: 'معاملات بسته', value: closedTrades.length.toString(), positive: true)),
            const SizedBox(width: 12),
            Expanded(child: _StatBox(title: 'سرمایه اولیه', value: '\$1000', positive: true)),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: premiumBox(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('یادآوری مهم', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 8),
              Text(
                'این برنامه فقط برای آموزش و تمرین ترید است. معاملات واقعی نیستند، پول واقعی جابه‌جا نمی‌شود و قیمت‌ها سیگنال خرید یا فروش محسوب نمی‌شوند.',
                style: mutedStyle(height: 1.7),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: () => _confirmReset(context),
          icon: const Icon(Icons.restart_alt_rounded),
          label: const Text('ریست حساب دمو و شروع دوباره'),
        ),
      ],
    );
  }

  void _confirmReset(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ریست حساب دمو؟'),
        content: const Text('همه معاملات باز و تاریخچه حذف می‌شود و حساب دوباره با ۱۰۰۰ دلار شروع می‌شود.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              onReset();
            },
            child: const Text('ریست کن'),
          ),
        ],
      ),
    );
  }
}

class _MarketsPage extends StatelessWidget {
  final Map<String, double> prices;
  final Map<String, List<double>> history;
  final bool updatingPrices;
  final VoidCallback onRefresh;
  final void Function(MarketAsset asset) onOpenTrade;

  const _MarketsPage({
    required this.prices,
    required this.history,
    required this.updatingPrices,
    required this.onRefresh,
    required this.onOpenTrade,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('بازار کریپتو', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                  SizedBox(height: 4),
                  Text('قیمت‌ها از اینترنت دریافت می‌شوند؛ معامله‌ها دمو هستند.', style: TextStyle(color: Color(0xFF8CA0BA))),
                ],
              ),
            ),
            IconButton.filledTonal(
              onPressed: updatingPrices ? null : onRefresh,
              icon: updatingPrices
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.sync_rounded),
            ),
          ],
        ),
        const SizedBox(height: 16),
        for (final asset in marketAssets)
          _MarketCard(
            asset: asset,
            price: prices[asset.symbol] ?? asset.fallbackPrice,
            points: history[asset.symbol] ?? [asset.fallbackPrice],
            onTap: () => onOpenTrade(asset),
          ),
      ],
    );
  }
}

class _MarketCard extends StatelessWidget {
  final MarketAsset asset;
  final double price;
  final List<double> points;
  final VoidCallback onTap;

  const _MarketCard({required this.asset, required this.price, required this.points, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final positive = points.length < 2 || points.last >= points.first;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: premiumBox(),
      child: Column(
        children: [
          Row(
            children: [
              _CoinBadge(text: asset.badge),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(asset.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    Text(asset.subtitle, style: mutedStyle()),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(formatMoney(price), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  Text(positive ? 'حرکت مثبت' : 'حرکت منفی', style: TextStyle(color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B), fontSize: 12)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(height: 74, child: PriceSparkline(points: points, positive: positive)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: onTap,
              icon: const Icon(Icons.add_chart_rounded),
              label: const Text('تمرین معامله دمو'),
            ),
          ),
        ],
      ),
    );
  }
}

class _TradesPage extends StatelessWidget {
  final List<PaperTrade> openTrades;
  final List<ClosedTrade> closedTrades;
  final Map<String, double> prices;
  final Future<void> Function(PaperTrade trade) onClose;

  const _TradesPage({
    required this.openTrades,
    required this.closedTrades,
    required this.prices,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('معاملات دمو', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text('پوزیشن‌های باز و تاریخچه فقط روی همین گوشی ذخیره می‌شوند.', style: mutedStyle()),
        const SizedBox(height: 18),
        const Text('پوزیشن‌های باز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (openTrades.isEmpty) _EmptyBox(text: 'هنوز معامله بازی نداری.'),
        for (final trade in openTrades)
          _OpenTradeCard(
            trade: trade,
            currentPrice: prices[trade.symbol] ?? trade.entryPrice,
            onClose: () => onClose(trade),
          ),
        const SizedBox(height: 18),
        const Text('تاریخچه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (closedTrades.isEmpty) _EmptyBox(text: 'تاریخچه‌ای ثبت نشده است.'),
        for (final trade in closedTrades.take(30)) _ClosedTradeCard(trade: trade),
      ],
    );
  }
}

class _OpenTradeCard extends StatelessWidget {
  final PaperTrade trade;
  final double currentPrice;
  final VoidCallback onClose;

  const _OpenTradeCard({required this.trade, required this.currentPrice, required this.onClose});

  @override
  Widget build(BuildContext context) {
    final profit = trade.pnl(currentPrice);
    final positive = profit >= 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: premiumBox(),
      child: Column(
        children: [
          Row(
            children: [
              Icon(trade.side == 'BUY' ? Icons.north_east_rounded : Icons.south_west_rounded, color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B)),
              const SizedBox(width: 10),
              Expanded(child: Text('${trade.title} - ${trade.side == 'BUY' ? 'خرید' : 'فروش'}', style: const TextStyle(fontWeight: FontWeight.w900))),
              Text(signedMoney(profit), style: TextStyle(color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B), fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 10),
          _InfoLine(title: 'مبلغ ورود', value: formatMoney(trade.amount)),
          _InfoLine(title: 'قیمت ورود', value: formatMoney(trade.entryPrice)),
          _InfoLine(title: 'قیمت فعلی', value: formatMoney(currentPrice)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: onClose,
              icon: const Icon(Icons.lock_rounded),
              label: const Text('بستن معامله دمو'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ClosedTradeCard extends StatelessWidget {
  final ClosedTrade trade;
  const _ClosedTradeCard({required this.trade});

  @override
  Widget build(BuildContext context) {
    final positive = trade.profit >= 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.045),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Icon(positive ? Icons.check_circle_rounded : Icons.cancel_rounded, color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${trade.trade.title} - ${trade.trade.side == 'BUY' ? 'خرید' : 'فروش'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                Text('ورود ${formatMoney(trade.trade.entryPrice)} / خروج ${formatMoney(trade.exitPrice)}', style: mutedStyle(fontSize: 12)),
              ],
            ),
          ),
          Text(signedMoney(trade.profit), style: TextStyle(color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B), fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _LearnPage extends StatelessWidget {
  const _LearnPage();

  @override
  Widget build(BuildContext context) {
    final lessons = [
      ('شروع ترید دمو', 'اول با حساب دمو تمرین کن. هدف نسخه اولیه یادگیری رفتار بازار و مدیریت سرمایه است.'),
      ('مدیریت ریسک', 'هیچ‌وقت کل سرمایه را وارد یک معامله نکن. در این اپ می‌توانی با مبلغ‌های کوچک تمرین کنی.'),
      ('Buy و Sell', 'Buy یعنی انتظار رشد قیمت. Sell یعنی تمرین سناریوی افت قیمت. هر دو فقط آموزشی هستند.'),
      ('سود و ضرر', 'سود/ضرر از اختلاف قیمت ورود و قیمت فعلی محاسبه می‌شود و بعد از بستن معامله به حساب دمو برمی‌گردد.'),
      ('هشدار آموزشی', 'این اپ سیگنال خرید و فروش نیست. فقط محیط تمرین با قیمت عمومی بازار است.'),
    ];
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('آموزش ترید', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text('درس‌های کوتاه برای شروع تمرین با حساب دمو.', style: mutedStyle()),
        const SizedBox(height: 18),
        for (int i = 0; i < lessons.length; i++)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: premiumBox(),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 38,
                  height: 38,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF00D09C).withOpacity(0.14),
                  ),
                  child: Text('${i + 1}', style: const TextStyle(color: Color(0xFF00D09C), fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(lessons[i].$1, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text(lessons[i].$2, style: mutedStyle(height: 1.7)),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class _StatBox extends StatelessWidget {
  final String title;
  final String value;
  final bool positive;

  const _StatBox({required this.title, required this.value, required this.positive});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: premiumBox(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: mutedStyle(fontSize: 12)),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B))),
        ],
      ),
    );
  }
}

class _CoinBadge extends StatelessWidget {
  final String text;
  const _CoinBadge({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52,
      height: 52,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(colors: [Color(0xFFFFD166), Color(0xFFFFA600)]),
        boxShadow: [BoxShadow(color: const Color(0xFFFFA600).withOpacity(0.22), blurRadius: 22)],
      ),
      child: Text(text.length > 4 ? text.substring(0, 4) : text, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 12)),
    );
  }
}

class _ChoiceButton extends StatelessWidget {
  final String label;
  final bool active;
  final bool positive;
  final VoidCallback onTap;

  const _ChoiceButton({required this.label, required this.active, required this.positive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.18) : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: active ? color : Colors.white.withOpacity(0.08)),
        ),
        child: Text(label, style: TextStyle(color: active ? color : Colors.white, fontWeight: FontWeight.w900)),
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String title;
  final String value;
  const _InfoLine({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(
        children: [
          Expanded(child: Text(title, style: mutedStyle(fontSize: 12))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _EmptyBox extends StatelessWidget {
  final String text;
  const _EmptyBox({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: premiumBox(),
      child: Center(child: Text(text, style: mutedStyle())),
    );
  }
}

class PriceSparkline extends StatelessWidget {
  final List<double> points;
  final bool positive;
  const PriceSparkline({super.key, required this.points, required this.positive});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _SparklinePainter(points: points, positive: positive),
      child: const SizedBox.expand(),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  final List<double> points;
  final bool positive;

  _SparklinePainter({required this.points, required this.positive});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = positive ? const Color(0xFF00D09C) : const Color(0xFFFF6B6B);

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = paint.color.withOpacity(0.08);

    final gridPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withOpacity(0.06);

    for (int i = 1; i <= 2; i++) {
      final y = size.height * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    if (points.length < 2) {
      canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), paint);
      return;
    }

    final minValue = points.reduce(math.min);
    final maxValue = points.reduce(math.max);
    final range = math.max(0.0000001, maxValue - minValue);

    final path = Path();
    final area = Path();
    for (int i = 0; i < points.length; i++) {
      final x = points.length == 1 ? 0.0 : size.width * i / (points.length - 1);
      final y = size.height - ((points[i] - minValue) / range * size.height);
      if (i == 0) {
        path.moveTo(x, y);
        area.moveTo(x, size.height);
        area.lineTo(x, y);
      } else {
        path.lineTo(x, y);
        area.lineTo(x, y);
      }
      if (i == points.length - 1) {
        area.lineTo(x, size.height);
        area.close();
      }
    }

    canvas.drawPath(area, fillPaint);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter oldDelegate) {
    return oldDelegate.points != points || oldDelegate.positive != positive;
  }
}

BoxDecoration premiumBox() {
  return BoxDecoration(
    color: Colors.white.withOpacity(0.065),
    borderRadius: BorderRadius.circular(24),
    border: Border.all(color: Colors.white.withOpacity(0.08)),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.22),
        blurRadius: 24,
        offset: const Offset(0, 14),
      ),
    ],
  );
}

TextStyle mutedStyle({double fontSize = 13, double height = 1.4}) {
  return TextStyle(color: const Color(0xFF8CA0BA), fontSize: fontSize, height: height);
}

String formatMoney(double value) {
  final absValue = value.abs();
  final decimals = absValue >= 100 ? 2 : absValue >= 1 ? 3 : 5;
  return '\$${value.toStringAsFixed(decimals)}';
}

String signedMoney(double value) {
  final sign = value >= 0 ? '+' : '-';
  return '$sign${formatMoney(value.abs())}';
}

double _asDouble(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse(value?.toString() ?? '') ?? 0;
}

List<PaperTrade> _decodeOpenTrades(String raw) {
  try {
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded.map((item) => PaperTrade.fromJson(Map<String, dynamic>.from(item as Map))).toList();
  } catch (_) {
    return [];
  }
}

List<ClosedTrade> _decodeClosedTrades(String raw) {
  try {
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded.map((item) => ClosedTrade.fromJson(Map<String, dynamic>.from(item as Map))).toList();
  } catch (_) {
    return [];
  }
}
